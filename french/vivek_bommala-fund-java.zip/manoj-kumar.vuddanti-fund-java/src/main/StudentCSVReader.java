package main;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class StudentCSVReader {
    private String filePath;

    public StudentCSVReader(String filePath) {
        this.filePath = filePath;
    }

    public List<Student> readAll() {
        List<Student> students = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            // Skip the header line
            if ((line = br.readLine()) != null) {
                while ((line = br.readLine()) != null) {
                    String[] fields = line.split(",");
                    students.add(new Student(fields[0], fields[1], Double.parseDouble(fields[2]), fields[3])); // Adjust indices
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
        return students;
    }
}