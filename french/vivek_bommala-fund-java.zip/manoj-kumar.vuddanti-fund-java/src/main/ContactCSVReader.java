package main;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ContactCSVReader {
    private String filePath;

    public ContactCSVReader(String filePath) {
        this.filePath = filePath;
    }

    public List<Contact> readAll() {
        List<Contact> contacts = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            // Skip the header line
            if ((line = br.readLine()) != null) {
                while ((line = br.readLine()) != null) {
                    String[] fields = line.split(",");
                    contacts.add(new Contact(fields[0], fields[1], fields[2])); // Adjust indices based on fields
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading file: " + e.getMessage());
        }
        return contacts;
    }
}