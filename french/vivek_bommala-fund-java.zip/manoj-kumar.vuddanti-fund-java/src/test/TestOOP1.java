package test;

public class TestOOP1 {
    public static void main(String[] args) {

        System.out.println("manoj-kumar.vuddanti");
    }
}