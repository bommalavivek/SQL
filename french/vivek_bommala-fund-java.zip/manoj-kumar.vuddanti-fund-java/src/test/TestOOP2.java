package test;

import main.Contact;
import main.ContactCSVReader;
import main.Student;
import main.StudentCSVReader;

import java.util.List;

public class TestOOP2 {
    public static void main(String[] args) {
        // File paths
        String contactsFilePath = "resources/contacts.csv";
        String studentsFilePath = "resources/students.csv";

        // Contact Reader
        ContactCSVReader contactReader = new ContactCSVReader(contactsFilePath);
        List<Contact> contacts = contactReader.readAll();
        System.out.println("Contacts:");
        for (Contact contact : contacts) {
            System.out.println(contact);
        }

        // Student Reader
        StudentCSVReader studentReader = new StudentCSVReader(studentsFilePath);
        List<Student> students = studentReader.readAll();
        System.out.println("\nStudents:");
        for (Student student : students) {
            System.out.println(student);
        }
    }
}